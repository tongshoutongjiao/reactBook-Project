---
name: Issues have been disabled
about: Please report new issues at github.com/facebook/react
title: NEW ISSUES ARE NOT MONITORED
labels: ''
assignees: ''

---

This repository has been merged into the main React repo (github.com/facebook/react)

Please open issues there:
https://github.com/facebook/react/issues/new

New issues opened in this repository will be ignored.
