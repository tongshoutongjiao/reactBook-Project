#### This project has migrated to [github.com/facebook/react](https://github.com/facebook/react)

The source code for the v3 of the extension can be found in the [`v3` branch](https://github.com/facebook/react-devtools/tree/v3).

To build the v3 browser extension from source:
```sh
git checkout v3

# Install dependencies and build the unpacked extension
yarn install
yarn build:extension

# Follow the on-screen instructions to complete installation
```